
import React, { useState, useCallback } from 'react';
import { Question } from '../types';
import { generateQuizQuestions } from '../services/geminiService';
import { BrainCircuit, Loader, Trash, Upload } from './Icons';

// Simple client-side CSV parser
const parseCSV = (csvText: string): Question[] => {
    const lines = csvText.trim().split('\n');
    // Skip header
    const dataLines = lines.slice(1);
    return dataLines.map((line, index) => {
        const [text, opt1, opt2, opt3, opt4, correct] = line.split(',').map(s => s.trim());
        return {
            id: `csv-${Date.now()}-${index}`,
            text,
            options: [opt1, opt2, opt3, opt4],
            correct: parseInt(correct, 10),
        };
    });
};

const QuizCreator: React.FC = () => {
    const [quizTitle, setQuizTitle] = useState('');
    const [questions, setQuestions] = useState<Question[]>([]);
    const [aiTopic, setAiTopic] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState('');
    const [successMessage, setSuccessMessage] = useState('');

    const handleGenerateWithAI = async () => {
        if (!aiTopic) {
            setError('অনুগ্রহ করে AI এর জন্য একটি বিষয় দিন।');
            return;
        }
        setIsLoading(true);
        setError('');
        setSuccessMessage('');
        try {
            const newQuestions = await generateQuizQuestions(aiTopic);
            setQuestions(prev => [...prev, ...newQuestions]);
            setSuccessMessage(`${newQuestions.length} টি প্রশ্ন সফলভাবে তৈরি হয়েছে।`);
        } catch (err: any) {
            setError(err.message);
        } finally {
            setIsLoading(false);
        }
    };

    const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = (e) => {
                const text = e.target?.result as string;
                try {
                    const parsedQuestions = parseCSV(text);
                    setQuestions(prev => [...prev, ...parsedQuestions]);
                    setSuccessMessage(`CSV থেকে ${parsedQuestions.length} টি প্রশ্ন যোগ করা হয়েছে।`);
                } catch (err) {
                    setError('CSV ফাইলটি পার্স করা যায়নি। ফরম্যাট সঠিক আছে কিনা দেখুন।');
                }
            };
            reader.readAsText(file);
        }
    };

    const removeQuestion = (id: string) => {
        setQuestions(prev => prev.filter(q => q.id !== id));
    };

    return (
        <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold text-slate-800 mb-6">নতুন কুইজ তৈরি করুন</h2>
            
            {error && <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">{error}</div>}
            {successMessage && <div className="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4" role="alert">{successMessage}</div>}

            <div className="bg-white p-8 rounded-xl shadow-md border border-slate-200 mb-8">
                <div className="mb-6">
                    <label htmlFor="quizTitle" className="block text-lg font-medium text-slate-700 mb-2">কুইজের শিরোনাম</label>
                    <input type="text" id="quizTitle" value={quizTitle} onChange={e => setQuizTitle(e.target.value)} className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-blue-500 focus:border-blue-500" placeholder="যেমন: ICT অধ্যায় ৫ মডেল টেস্ট"/>
                </div>
            </div>

            <div className="grid md:grid-cols-2 gap-8 mb-8">
                {/* AI Generator */}
                <div className="bg-white p-6 rounded-xl shadow-md border border-slate-200">
                    <h3 className="text-xl font-semibold text-slate-800 mb-4 flex items-center"><BrainCircuit className="mr-2 text-blue-500" /> AI দিয়ে প্রশ্ন তৈরি</h3>
                    <p className="text-sm text-slate-500 mb-4">একটি বিষয় লিখে দিন, AI আপনার জন্য প্রশ্ন তৈরি করে দেবে।</p>
                    <input type="text" value={aiTopic} onChange={e => setAiTopic(e.target.value)} className="w-full px-4 py-2 border border-slate-300 rounded-lg mb-4" placeholder="যেমন: কম্পিউটার নেটওয়ার্ক"/>
                    <button onClick={handleGenerateWithAI} disabled={isLoading} className="w-full bg-blue-600 text-white font-bold py-2 px-4 rounded-lg hover:bg-blue-700 disabled:bg-blue-300 flex items-center justify-center">
                        {isLoading ? <Loader className="animate-spin" /> : 'প্রশ্ন তৈরি করুন'}
                    </button>
                </div>

                {/* CSV Uploader */}
                <div className="bg-white p-6 rounded-xl shadow-md border border-slate-200">
                     <h3 className="text-xl font-semibold text-slate-800 mb-4 flex items-center"><Upload className="mr-2 text-green-500" /> CSV থেকে প্রশ্ন আপলোড</h3>
                     <p className="text-sm text-slate-500 mb-4">ফরম্যাট: question_text, option1, option2, option3, option4, correct_answer_index (0-3)</p>
                     <label className="w-full cursor-pointer bg-green-600 text-white font-bold py-2 px-4 rounded-lg hover:bg-green-700 flex items-center justify-center">
                        <Upload className="mr-2" /> ফাইল আপলোড করুন
                        <input type="file" accept=".csv" onChange={handleFileUpload} className="hidden" />
                     </label>
                </div>
            </div>

            {/* Questions List */}
            <div className="bg-white p-8 rounded-xl shadow-md border border-slate-200">
                <h3 className="text-xl font-semibold text-slate-800 mb-4">প্রশ্ন ব্যাংক ({questions.length})</h3>
                <div className="space-y-4 max-h-96 overflow-y-auto pr-2">
                    {questions.length > 0 ? questions.map((q, index) => (
                        <div key={q.id} className="p-4 border border-slate-200 rounded-lg">
                            <div className="flex justify-between items-start">
                                <p className="font-semibold">{index + 1}. {q.text}</p>
                                <button onClick={() => removeQuestion(q.id)} className="text-red-500 hover:text-red-700"><Trash /></button>
                            </div>
                            <ul className="list-disc list-inside mt-2 space-y-1 text-sm">
                                {q.options.map((opt, i) => (
                                    <li key={i} className={i === q.correct ? 'text-green-600 font-bold' : 'text-slate-600'}>{opt}</li>
                                ))}
                            </ul>
                        </div>
                    )) : <p className="text-slate-500 text-center py-4">এখনো কোনো প্রশ্ন যোগ করা হয়নি।</p>}
                </div>
                 <button disabled={!quizTitle || questions.length === 0} className="w-full mt-6 bg-indigo-600 text-white font-bold py-3 px-4 rounded-lg hover:bg-indigo-700 disabled:bg-indigo-300 flex items-center justify-center">
                    কুইজ তৈরি করুন
                </button>
            </div>
        </div>
    );
};

export default QuizCreator;
