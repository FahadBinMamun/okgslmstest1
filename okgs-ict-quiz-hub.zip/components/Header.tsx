
import React from 'react';
import { useAppContext } from '../App';
import { LogoutIcon } from './Icons';

const Header: React.FC = () => {
  const { currentUser, logout } = useAppContext();

  return (
    <header className="bg-white shadow-sm p-4 flex justify-between items-center">
      <h1 className="text-xl font-semibold text-gray-800">
        স্বাগতম, {currentUser?.name || 'ব্যবহারকারী'}
      </h1>
      <div className="flex items-center space-x-4">
        <button
            onClick={logout}
            className="flex items-center space-x-2 text-sm font-medium text-red-500 hover:text-red-700 p-2 rounded-lg hover:bg-red-50 transition-colors"
        >
            <LogoutIcon />
            <span>লগ আউট</span>
        </button>
      </div>
    </header>
  );
};

export default Header;