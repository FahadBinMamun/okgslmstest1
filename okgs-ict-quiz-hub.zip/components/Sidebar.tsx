
import React from 'react';
import { useAppContext } from '../App';
import { BookOpen, Home, PlusCircle, UserCheck, Users } from 'lucide-react';
import { UserRole } from '../types';

interface NavLinkProps {
  href: string; // e.g. "/dashboard"
  children: React.ReactNode;
  icon: React.ReactNode;
}

const NavLink: React.FC<NavLinkProps> = ({ href, children, icon }) => {
    const { navigate, route } = useAppContext();
    // The route from context includes the hash, e.g., #/dashboard
    // The href passed is without the hash, e.g., /dashboard
    const isActive = route === `#${href}`;

    return (
        <a
            href={`#${href}`}
            onClick={(e) => {
                e.preventDefault();
                navigate(href);
            }}
            className={`flex items-center px-4 py-3 text-base font-medium rounded-lg transition-colors duration-200 ${
                isActive
                ? 'bg-blue-600 text-white'
                : 'text-blue-100 hover:bg-blue-800 hover:text-white'
            }`}
        >
            {icon}
            <span className="ml-3">{children}</span>
        </a>
    );
};

const Sidebar = ({ userRole }: { userRole: UserRole }) => {
  return (
    <aside className="w-64 flex-shrink-0 bg-blue-900 text-white flex-col p-4 hidden md:flex">
        <div className="text-2xl font-bold text-center py-4 border-b border-blue-800">
            OKGS ICT Hub
        </div>
        <nav className="mt-6 flex-1 space-y-2">
            <NavLink href="/dashboard" icon={<Home />}>ড্যাশবোর্ড</NavLink>
            
            {userRole === 'student' && (
                <>
                    <NavLink href="/courses" icon={<BookOpen />}>কোর্সসমূহ</NavLink>
                    <NavLink href="/quiz/take/ict-ch1-quiz" icon={<PlusCircle />}>মডেল টেস্ট দিন</NavLink>
                </>
            )}

            {userRole === 'teacher' && (
                <>
                    <NavLink href="/teacher/create-course" icon={<PlusCircle />}>নতুন কোর্স</NavLink>
                    <NavLink href="/teacher/create-quiz" icon={<PlusCircle />}>নতুন কুইজ</NavLink>
                    <NavLink href="/teacher/students" icon={<Users />}>ছাত্রছাত্রী</NavLink>
                </>
            )}

            {userRole === 'admin' && (
                <>
                    <NavLink href="/admin/manage-courses" icon={<BookOpen />}>কোর্স ম্যানেজ</NavLink>
                    <NavLink href="/admin/manage-users" icon={<UserCheck />}>ইউজার ম্যানেজ</NavLink>
                </>
            )}

            <div className='pt-4 border-t border-blue-800'>
                 <p className="px-4 text-xs text-blue-300">শীঘ্রই আসছে...</p>
                 <a className="flex items-center px-4 py-3 text-blue-300 opacity-50 cursor-not-allowed">
                    <BookOpen /> <span className="ml-3">সার্টিফিকেট</span>
                 </a>
            </div>
        </nav>
    </aside>
  );
};

export default Sidebar;