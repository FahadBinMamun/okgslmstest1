
import React, { useState, useEffect } from 'react';
import { useAppContext } from '../App';
import { Quiz, Question } from '../types';
import { Loader, Clock } from './Icons';
import { mockQuizzes } from '../data/mockData';

interface QuizTakerProps {
  quizId: string;
}

const QuizTaker: React.FC<QuizTakerProps> = ({ quizId }) => {
    const { navigate } = useAppContext();
    const [quiz, setQuiz] = useState<Quiz | null>(null);
    const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
    const [answers, setAnswers] = useState<(number | null)[]>([]);
    const [timeLeft, setTimeLeft] = useState(30 * 60); // 30 minutes in seconds

    useEffect(() => {
        // Mock fetching quiz data
        const foundQuiz = mockQuizzes.find(q => q.id === quizId);
        if (foundQuiz) {
            setQuiz(foundQuiz);
            setAnswers(new Array(foundQuiz.questions.length).fill(null));
        }
    }, [quizId]);

    useEffect(() => {
        if (!quiz) return;
        if (timeLeft <= 0) {
            handleSubmit();
            return;
        }
        const timerId = setInterval(() => setTimeLeft(timeLeft - 1), 1000);
        return () => clearInterval(timerId);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [timeLeft, quiz]);

    const handleAnswerSelect = (optionIndex: number) => {
        const newAnswers = [...answers];
        newAnswers[currentQuestionIndex] = optionIndex;
        setAnswers(newAnswers);
    };

    const handleSubmit = () => {
        if (!quiz) return;
        let score = 0;
        quiz.questions.forEach((q, index) => {
            if (answers[index] === q.correct) {
                score++;
            }
        });
        navigate(`/quiz/result/${score}/${quiz.questions.length}`);
    };

    if (!quiz) {
        return <div className="flex justify-center items-center h-full"><Loader className="animate-spin text-blue-500" size={48} /></div>;
    }

    const currentQuestion = quiz.questions[currentQuestionIndex];
    const minutes = Math.floor(timeLeft / 60);
    const seconds = timeLeft % 60;

    return (
        <div className="max-w-3xl mx-auto bg-white p-8 rounded-xl shadow-xl border border-slate-200">
            <div className="flex justify-between items-center mb-6 pb-4 border-b">
                <h2 className="text-2xl font-bold text-slate-800">{quiz.title}</h2>
                <div className="flex items-center text-lg font-semibold bg-red-100 text-red-600 px-4 py-2 rounded-lg">
                    <Clock className="mr-2" />
                    <span>{String(minutes).padStart(2, '0')}:{String(seconds).padStart(2, '0')}</span>
                </div>
            </div>

            <div>
                <p className="text-lg font-semibold text-slate-700 mb-4">প্রশ্ন {currentQuestionIndex + 1}/{quiz.questions.length}:</p>
                <p className="text-xl mb-6">{currentQuestion.text}</p>
                
                <div className="space-y-4">
                    {currentQuestion.options.map((option, index) => (
                        <label key={index} className={`block p-4 border rounded-lg cursor-pointer transition-all ${answers[currentQuestionIndex] === index ? 'bg-blue-100 border-blue-500 ring-2 ring-blue-500' : 'bg-slate-50 border-slate-300 hover:bg-slate-100'}`}>
                            <input type="radio" name="option" value={index} checked={answers[currentQuestionIndex] === index} onChange={() => handleAnswerSelect(index)} className="hidden" />
                            <span className="text-md">{option}</span>
                        </label>
                    ))}
                </div>
            </div>

            <div className="flex justify-between mt-8 pt-6 border-t">
                <button 
                    onClick={() => setCurrentQuestionIndex(prev => prev - 1)} 
                    disabled={currentQuestionIndex === 0}
                    className="bg-slate-500 text-white font-bold py-2 px-6 rounded-lg hover:bg-slate-600 disabled:bg-slate-300"
                >পূর্ববর্তী</button>
                
                {currentQuestionIndex < quiz.questions.length - 1 ? (
                    <button 
                        onClick={() => setCurrentQuestionIndex(prev => prev + 1)}
                        className="bg-blue-600 text-white font-bold py-2 px-6 rounded-lg hover:bg-blue-700"
                    >পরবর্তী</button>
                ) : (
                    <button 
                        onClick={handleSubmit}
                        className="bg-green-600 text-white font-bold py-2 px-6 rounded-lg hover:bg-green-700"
                    >কুইজ জমা দিন</button>
                )}
            </div>
        </div>
    );
};

export default QuizTaker;
