
import React from 'react';
import { UserRole } from '../types';
import { UserIcon, BriefcaseIcon, ShieldIcon } from './Icons';

interface LoginProps {
    onLogin: (role: UserRole) => void;
}

const Login: React.FC<LoginProps> = ({ onLogin }) => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex flex-col justify-center items-center p-4 font-sans">
        <div className="text-center mb-12">
            <h1 className="text-4xl md:text-5xl font-extrabold text-blue-900">OKGS ICT Quiz Hub</h1>
            <p className="text-slate-600 mt-2 text-lg">আপনার শেখার নতুন ঠিকানা</p>
        </div>

        <div className="w-full max-w-sm space-y-4">
            <LoginButton
                role="student"
                label="ছাত্র হিসেবে লগইন করুন"
                icon={<UserIcon />}
                onClick={onLogin}
                className="bg-blue-600 hover:bg-blue-700"
            />
            <LoginButton
                role="teacher"
                label="শিক্ষক হিসেবে লগইন করুন"
                icon={<BriefcaseIcon />}
                onClick={onLogin}
                className="bg-teal-600 hover:bg-teal-700"
            />
            <LoginButton
                role="admin"
                label="অ্যাডমিন হিসেবে লগইন করুন"
                icon={<ShieldIcon />}
                onClick={onLogin}
                className="bg-indigo-600 hover:bg-indigo-700"
            />
        </div>

        <div className="absolute bottom-4 text-xs text-gray-500">
            Fahad Bin Mamun কর্তৃক ALPCG ক্লাবের অধীনে নির্মিত
        </div>
    </div>
  );
};

interface LoginButtonProps {
    role: UserRole;
    label: string;
    icon: React.ReactNode;
    onClick: (role: UserRole) => void;
    className: string;
}

const LoginButton: React.FC<LoginButtonProps> = ({ role, label, icon, onClick, className }) => (
    <button
        onClick={() => onClick(role)}
        className={`w-full flex items-center justify-center text-white font-bold py-3 px-4 rounded-lg shadow-lg transform hover:-translate-y-1 transition-all duration-300 ease-in-out ${className}`}
    >
        <span className="mr-3">{icon}</span>
        {label}
    </button>
);


export default Login;
