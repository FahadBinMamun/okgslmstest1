
import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-white border-t border-gray-200 px-4 py-2 text-center text-xs text-gray-500">
      Fahad Bin Mamun কর্তৃক ALPCG ক্লাবের অধীনে নির্মিত
    </footer>
  );
};

export default Footer;
