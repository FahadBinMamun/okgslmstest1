
import './globals.css';
import { Inter } from 'next/font/google';
import { ClerkProvider } from '@clerk/nextjs';
import { bnBD } from '@clerk/localizations';

const inter = Inter({ subsets: ['latin'] });

export const metadata = {
  title: 'OKGS ICT Quiz Hub',
  description: 'Next.js ভিত্তিক একটি পূর্ণাঙ্গ লার্নিং ও কুইজ প্ল্যাটফর্ম।',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <ClerkProvider localization={bnBD}>
      <html lang="bn">
        <body className={inter.className}>
          {children}
        </body>
      </html>
    </ClerkProvider>
  );
}
