
import { Button } from '@/components/ui/Button';
import Link from 'next/link';
import { BookOpen } from 'lucide-react';

export default function LandingPage() {
  return (
    <main className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex flex-col justify-center items-center p-4 font-sans">
      <div className="text-center">
        <div className="inline-block bg-white p-4 rounded-full shadow-lg mb-6">
          <BookOpen className="h-12 w-12 text-blue-600" />
        </div>
        <h1 className="text-4xl md:text-6xl font-extrabold text-blue-900 leading-tight">
          OKGS ICT Quiz Hub
        </h1>
        <p className="text-slate-600 mt-4 text-lg max-w-2xl mx-auto">
          আপনার জ্ঞান পরীক্ষা এবং পরীক্ষার প্রস্তুতির জন্য আধুনিক একটি প্ল্যাটফর্ম। আজই যোগ দিন এবং আপনার শেখা শুরু করুন।
        </p>
      </div>

      <div className="mt-12 flex flex-col sm:flex-row gap-4">
        <Button asChild size="lg" className="bg-blue-600 hover:bg-blue-700 text-white shadow-lg">
          <Link href="/sign-in">লগইন করুন</Link>
        </Button>
        <Button asChild variant="outline" size="lg" className="bg-white hover:bg-slate-50 shadow-lg">
          <Link href="/sign-up">নতুন অ্যাকাউন্ট তৈরি করুন</Link>
        </Button>
      </div>

      <div className="absolute bottom-4 text-xs text-gray-500">
        Fahad Bin Mamun কর্তৃক ALPCG ক্লাবের অধীনে নির্মিত
      </div>
    </main>
  );
}
