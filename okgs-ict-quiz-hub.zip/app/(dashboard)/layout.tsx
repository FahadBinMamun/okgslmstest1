
import React from 'react';
import Header from '@/components/Header';
import Sidebar from '@/components/Sidebar';
import Footer from '@/components/Footer';
import { getUserRole } from '@/lib/actions';


export default async function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {

  const userRole = await getUserRole();

  return (
      <div className="flex h-screen bg-slate-100 font-sans">
        <Sidebar userRole={userRole} />
        <div className="flex-1 flex flex-col overflow-hidden">
          <Header />
          <main className="flex-1 overflow-x-hidden overflow-y-auto bg-slate-50 p-4 md:p-8">
            {children}
          </main>
          <Footer />
        </div>
      </div>
  );
}
