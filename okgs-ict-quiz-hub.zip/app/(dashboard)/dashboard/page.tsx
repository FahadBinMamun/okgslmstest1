
import { getUserRole } from '@/lib/actions';
import { BookOpen, CheckCircle, Edit, Users } from 'lucide-react';

const StatCard = ({ title, value, icon }: { title: string; value: string; icon: React.ReactNode }) => (
    <div className="bg-white p-6 rounded-xl shadow-md flex items-center space-x-4 border border-slate-200 hover:shadow-lg transition-shadow">
        <div className="bg-blue-100 text-blue-600 p-3 rounded-full">
            {icon}
        </div>
        <div>
            <p className="text-sm text-slate-500">{title}</p>
            <p className="text-2xl font-bold text-slate-800">{value}</p>
        </div>
    </div>
);

export default async function DashboardPage() {
    const role = await getUserRole();

    return (
        <div>
            <h2 className="text-3xl font-bold text-slate-800 mb-6">আপনার ড্যাশবোর্ড</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {role === 'student' && (
                    <>
                        <StatCard title="কোর্স এনরোলড" value="5" icon={<BookOpen />} />
                        <StatCard title="কুইজ সম্পন্ন" value="12" icon={<CheckCircle />} />
                        <StatCard title="অ্যাসাইনমেন্ট জমা" value="3" icon={<Edit />} />
                    </>
                )}
                 {role === 'teacher' && (
                    <>
                        <StatCard title="আপনার কোর্স" value="3" icon={<BookOpen />} />
                        <StatCard title="তৈরিকৃত কুইজ" value="8" icon={<Edit />} />
                        <StatCard title="মোট ছাত্রছাত্রী" value="150" icon={<Users />} />
                    </>
                )}
                 {role === 'admin' && (
                    <>
                        <StatCard title="মোট কোর্স" value="25" icon={<BookOpen />} />
                        <StatCard title="মোট শিক্ষক" value="10" icon={<Users />} />
                        <StatCard title="মোট ছাত্র" value="500+" icon={<Users />} />
                    </>
                )}
            </div>
            <div className="mt-10 bg-white p-6 rounded-xl shadow-md border border-slate-200">
                 <h3 className="text-xl font-semibold mb-4 text-slate-700">সাম্প্রতিক কার্যক্রম</h3>
                 <p className="text-slate-500">এখানে সাম্প্রতিক কার্যক্রম দেখানো হবে। যেমন নতুন কুইজ, নোটিশ ইত্যাদি।</p>
            </div>
        </div>
    );
};
