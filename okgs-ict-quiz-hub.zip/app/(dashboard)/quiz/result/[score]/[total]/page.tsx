
'use client';
import React from 'react';
import { useRouter } from 'next/navigation';
import { Award } from 'lucide-react';
import { Button } from '@/components/ui/Button';

export default function QuizResultPage({ params }: { params: { score: string, total: string } }) {
    const router = useRouter();
    const score = parseInt(params.score, 10);
    const total = parseInt(params.total, 10);
    const percentage = total > 0 ? Math.round((score / total) * 100) : 0;

    return (
        <div className="max-w-2xl mx-auto text-center bg-white p-10 rounded-xl shadow-2xl border border-slate-200">
            <Award className="mx-auto text-yellow-500 mb-4" size={64} />
            <h2 className="text-3xl font-bold text-slate-800 mb-2">অভিনন্দন!</h2>
            <p className="text-slate-600 mb-6">আপনি সফলভাবে কুইজটি সম্পন্ন করেছেন।</p>
            
            <div className="bg-slate-50 p-8 rounded-lg border border-slate-200 mb-8">
                <p className="text-lg text-slate-500 mb-2">আপনার স্কোর</p>
                <p className="text-6xl font-bold text-blue-600">
                    {score}<span className="text-3xl text-slate-400">/{total}</span>
                </p>
                <div className="w-full bg-slate-200 rounded-full h-4 mt-4">
                    <div className="bg-green-500 h-4 rounded-full" style={{ width: `${percentage}%` }}></div>
                </div>
                <p className="font-semibold text-green-600 mt-2">{percentage}% সঠিক উত্তর</p>
            </div>
            
            <Button
                onClick={() => router.push('/dashboard')}
                size="lg"
            >
                ড্যাশবোর্ডে ফিরে যান
            </Button>
        </div>
    );
};
