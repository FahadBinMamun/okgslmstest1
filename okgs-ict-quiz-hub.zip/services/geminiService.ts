
import { GoogleGenAI, Type } from "@google/genai";
import { Question } from "../types";

if (!process.env.API_KEY) {
    console.warn("API_KEY environment variable not set. AI features will not work.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });

const questionSchema = {
    type: Type.OBJECT,
    properties: {
        text: { type: Type.STRING, description: "The question text in Bengali." },
        options: {
            type: Type.ARRAY,
            description: "An array of 4 possible answers in Bengali.",
            items: { type: Type.STRING },
        },
        correct: { type: Type.INTEGER, description: "The 0-based index of the correct option in the options array." },
    },
    required: ["text", "options", "correct"],
};

const quizSchema = {
    type: Type.OBJECT,
    properties: {
        questions: {
            type: Type.ARRAY,
            description: "An array of 5 multiple-choice questions.",
            items: questionSchema,
        }
    },
    required: ["questions"],
};


export const generateQuizQuestions = async (topic: string): Promise<Question[]> => {
    if (!process.env.API_KEY) {
        throw new Error("AI Service is not configured. Missing API_KEY.");
    }

    try {
        const prompt = `Based on the topic "${topic}", generate 5 multiple-choice questions suitable for an ICT quiz in Bangladesh. The questions and options must be in Bengali. Ensure there are exactly 4 options for each question.`;

        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: quizSchema,
                temperature: 0.8,
            },
        });
        
        const jsonText = response.text;
        const result = JSON.parse(jsonText);
        
        if (result.questions && Array.isArray(result.questions)) {
             return result.questions.map((q: any, index: number) => ({
                id: `ai-${Date.now()}-${index}`,
                ...q,
            }));
        }
        return [];

    } catch (error) {
        console.error("Error generating quiz questions:", error);
        throw new Error("AI দ্বারা প্রশ্ন তৈরি করা সম্ভব হয়নি। অনুগ্রহ করে আবার চেষ্টা করুন।");
    }
};