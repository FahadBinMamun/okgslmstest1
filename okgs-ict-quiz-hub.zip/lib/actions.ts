
import { auth } from '@clerk/nextjs/server';
import { UserRole } from '@/types';

/**
 * Fetches the user's role from their authentication session.
 * This must be called from a server component or API route.
 * Note: Roles must be set in Clerk Dashboard under Users -> Select User -> Metadata -> Public Metadata
 * e.g., { "role": "teacher" }
 */
export const getUserRole = async (): Promise<UserRole> => {
    const { sessionClaims } = auth();
    
    const role = sessionClaims?.metadata?.role as UserRole;

    // Default to 'student' if no role is found
    if (!role || !['admin', 'teacher', 'student'].includes(role)) {
        return 'student';
    }

    return role;
};
